"use client";

import React, { useState, useEffect } from 'react';
import { Search, Sun, Cloud, Calendar, ExternalLink, Globe, ChevronDown } from 'lucide-react';

// Translations object
const translations = {
  EN: {
    greeting: {
      morning: 'Good Morning',
      afternoon: 'Good Afternoon',
      evening: 'Good Evening'
    },
    search: {
      placeholder: 'Search IVONI brands or find resources...',
      save: 'Save'
    }
  },
  ES: {
    greeting: {
      morning: 'Buenos Días',
      afternoon: 'Buenas Tardes',
      evening: 'Buenas Noches'
    },
    search: {
      placeholder: 'Buscar marcas, calcular o encontrar recursos...',
      save: 'Guardar'
    }
  },
  CAT: {
    greeting: {
      morning: 'Bon Dia',
      afternoon: 'Bona Tarda',
      evening: 'Bona Nit'
    },
    search: {
      placeholder: 'Cerca marques, calcula o troba recursos...',
      save: 'Desar'
    }
  }
};

// Fixed brands data structure
const brands = [
  {
    id: 'ivoni-core',
    name: 'IVONI Core',
    url: 'https://core.ivoni.org',
    description: 'Core brand services and solutions',
    subbrands: [
      {
        id: 'ivoni-housecore',
        name: 'IVONI Housecore',
        url: 'https://housecore.org',
        description: 'Comprehensive house style management'
      },
      {
        id: 'ivoni-brandcore',
        name: 'IVONI BrandCore',
        url: 'https://core.ivoni.org',
        description: 'Complete branding and identity solutions'
      }
    ]
  },
  {
    id: 'ivoni-global',
    name: 'IVONI',
    url: 'https://ivoni.org',
    description: 'Global digital transformation services',
    subbrands: [
      {
        id: 'ivoni-planblue',
        name: 'IVONI Plan Blue',
        url: 'https://ivoni.org/planblue',
        description: '100% Environmental Hosting'
      }
    ]
  },
  {
    id: 'ivoni-espana',
    name: 'IVONI España',
    url: 'https://ivoni.es',
    description: 'Spanish digital transformation services'
  },
  {
    id: 'ivoni-catalunya',
    name: 'IVONI Catalunya',
    url: 'https://ivoni.cat',
    description: 'Catalan digital transformation services'
  },
  {
    id: 'agencia-mira',
    name: 'AgenciaMira',
    url: 'https://agenciamira.es',
    description: 'Barcelona Based Creative Agency',
    subbrands: [
      {
        id: 'mirafest',
        name: 'MiraFest',
        url: 'https://mirafest.es',
        description: 'Barcelona Based Music Events'
      }
    ]
  }
];

// Fixed flattenBrands function
const flattenBrands = (brandsArray) => {
  if (!Array.isArray(brandsArray) || brandsArray.length === 0) {
    return [];
  }

  return brandsArray.reduce((acc, brand) => {
    // Add main brand
    acc.push({
      id: brand.id,
      name: brand.name,
      url: brand.url,
      description: brand.description,
      parentId: null
    });

    // Add subbrands if they exist
    if (Array.isArray(brand.subbrands)) {
      brand.subbrands.forEach(subbrand => {
        acc.push({
          id: subbrand.id,
          name: subbrand.name,
          url: subbrand.url || `https://${subbrand.id}.ivoni.org`,
          description: subbrand.description,
          parentId: brand.id
        });
      });
    }

    return acc;
  }, []);
};

const SearchResults = ({ results, searchTerm, onClose, onBrandClick }) => {
  if (!searchTerm) return null;

  const DisplayUrl = ({ url }) => {
    if (!url) return null;
    try {
      const hostname = new URL(url).hostname.replace('www.', '');
      return (
        <div className="text-xs bg-gray-100 px-2 py-1 rounded text-gray-600">
          {hostname}
        </div>
      );
    } catch {
      return null;
    }
  };

  return (
    <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-xl shadow-lg border border-gray-200 max-h-96 overflow-y-auto z-50">
      <div className="p-2">
        <div className="text-sm font-medium text-gray-500 px-3 py-2">
          {results.length ? `Found ${results.length} results` : 'No results found'}
        </div>
        {results.map(result => (
          <a
            key={result.id}
            href={result.url}
            target="_blank"
            rel="noopener noreferrer"
            className="block p-3 hover:bg-gray-50 rounded-lg group"
            onClick={() => onBrandClick(result)}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4 flex-grow">
                <img
                  src={`/api/placeholder/32/32`}
                  alt={`${result.name} logo`}
                  className="w-8 h-8 rounded"
                />
                <div className="min-w-0 flex-grow">
                  <div className="font-medium text-gray-900 flex items-center gap-2">
                    {result.parentId && <span className="text-gray-400">↳</span>}
                    {result.name}
                  </div>
                  <div className="text-sm text-gray-500 truncate">{result.description}</div>
                </div>
                <div className="flex items-center gap-3 flex-shrink-0">
                  <DisplayUrl url={result.url} />
                  <div className="w-px h-4 bg-gray-200"></div>
                  <ExternalLink className="w-4 h-4 text-blue-500 opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
              </div>
            </div>
          </a>
        ))}
      </div>
    </div>
  );
};

// LanguageSelector component
const LanguageSelector = ({ selectedLang, onSelect }) => {
  const [isOpen, setIsOpen] = useState(false);
  
  const languages = [
    { code: 'EN', key: '1' },
    { code: 'ES', key: '2' },
    { code: 'CAT', key: '3' }
  ];

  useEffect(() => {
    const handleKeyPress = (e) => {
      if (e.metaKey || e.ctrlKey) {
        const key = e.key;
        const language = languages.find(lang => lang.key === key);
        if (language) {
          e.preventDefault();
          onSelect(language.code);
        }
      }
    };
    
    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [onSelect]);

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-3 py-2 text-sm bg-white rounded-lg border border-gray-200 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
      >
        <Globe className="w-4 h-4 text-gray-500" />
        <span>{selectedLang}</span>
        <ChevronDown className="w-4 h-4 text-gray-500" />
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 bg-white rounded-lg shadow-lg border border-gray-200 overflow-hidden z-50">
          {languages.map(({ code, key }) => (
            <button
              key={code}
              onClick={() => {
                onSelect(code);
                setIsOpen(false);
              }}
              className="w-full px-4 py-2 text-left text-sm hover:bg-gray-50 flex items-center justify-between"
            >
              <span>{code}</span>
              <kbd className="px-2 py-0.5 text-xs bg-gray-100 rounded">⌘{key}</kbd>
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

// Main Dashboard component
export default function Dashboard() {

  const [searchTerm, setSearchTerm] = useState('');
  const [time, setTime] = useState(new Date());
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const [lang, setLang] = useState('EN');
  const [recentSearches, setRecentSearches] = useState([]);

  //new edit

  const handleBrandClick = React.useCallback((brand) => {
    setRecentSearches(prevSearches => {
      const filteredSearches = prevSearches.filter(s => s.id !== brand.id);
      return [brand, ...filteredSearches].slice(0, 4);
    });
  }, []);

  // Use the fixed flattenBrands function
  const flatBrands = React.useMemo(() => flattenBrands(brands), []);
  
  const evaluateExpression = (expr) => {
    try {
      // Replace × with *, ÷ with /
      const sanitizedExpr = expr.replace(/×/g, '*').replace(/÷/g, '/');
      // Only allow numbers, basic operators, parentheses, and decimals
      if (!/^[0-9+\-*/().\s×÷]+$/.test(sanitizedExpr)) {
        return null;
      }
      // eslint-disable-next-line no-new-func
      return Function(`'use strict'; return (${sanitizedExpr})`)();
    } catch {
      return null;
    }
  };

  const isCalculation = React.useMemo(() => {
    if (!searchTerm) return null;
    const result = evaluateExpression(searchTerm);
    return result !== null ? `= ${result}` : null;
  }, [searchTerm]);
  
  const filteredBrands = React.useMemo(() => {
    if (!searchTerm) return [];
    if (isCalculation) return [];  // Don't show brands during calculations
    const searchLower = searchTerm.toLowerCase();
    return flatBrands.filter(brand => 
      brand.name.toLowerCase().includes(searchLower) ||
      brand.description.toLowerCase().includes(searchLower)
    );
  }, [searchTerm, flatBrands, isCalculation]);

  useEffect(() => {
    const handleKeyPress = (e) => {
      if (e.key === 'k' && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        document.getElementById('search-input').focus();
      } else if (e.key === 'Escape') {
        setSearchTerm('');
        document.getElementById('search-input').blur();
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const getGreeting = () => {
    const hours = time.getHours();
    if (hours >= 5 && hours < 12) {
      return translations[lang].greeting.morning;
    } else if (hours >= 12 && hours < 18) {
      return translations[lang].greeting.afternoon;
    }
    return translations[lang].greeting.evening;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-8 py-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <img
              src="https://ivoni.org/wp-content/uploads/2021/11/IvoniLogo-Main-min.png"
              alt="IVONI IntraSystems Logo"
              className="w-12"
              />
              <div className="w-px h-6 bg-gray-200"></div>
              <span className="font-sans text-gray-800 font-medium">Intra-Sistema</span>
            </div>
            <LanguageSelector selectedLang={lang} onSelect={setLang} />
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="p-8 flex flex-col items-center justify-center min-h-[calc(100vh-64px)]">
        <div className="w-full max-w-3xl">
          {/* Greeting Section */}
          <div className="flex flex-col items-center mb-8">
            <img
              src="https://core.ivoni.org/wp-content/uploads/2024/10/IVONI-IntraSistema.png"
              alt="IVONI IntraSystems Logo"
              className="w-32 mb-4" // Smaller logo with bottom margin
            />
            <h1 className="text-4xl font-serif text-gray-800 text-center">{getGreeting()}</h1>
          </div>
          
          {/* Time Card */}
          <div className="bg-white rounded-xl p-4 shadow-sm mb-8 w-full">
            <div className="flex flex-col sm:flex-row items-center justify-between text-sm text-gray-600 gap-4">
  <div className="flex items-center gap-2">
    <Calendar className="w-4 h-4" />
    {time.toLocaleDateString(lang === 'EN' ? 'en-GB' : 'es-ES', { 
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    })}
  </div>
  <div className="flex items-center gap-4 text-xs sm:text-sm">
    <div className="flex items-center gap-1">
      <Sun className="w-3 h-3 sm:w-4 sm:h-4" />
      <span className="whitespace-nowrap">
        BCN: {time.toLocaleTimeString(lang === 'EN' ? 'en-GB' : 'es-ES', { 
          timeZone: 'Europe/Madrid',
          hour: '2-digit',
          minute: '2-digit'
        })}
      </span>
    </div>
    <div className="flex items-center gap-1">
      <Cloud className="w-3 h-3 sm:w-4 sm:h-4" />
      <span className="whitespace-nowrap">
        UK: {time.toLocaleTimeString(lang === 'EN' ? 'en-GB' : 'es-ES', { 
          timeZone: 'Europe/London',
          hour: '2-digit',
          minute: '2-digit'
        })}
      </span>
    </div>
  </div>
</div>
          </div>

        {/* Search Section */}
        <div className="relative w-full">
          <div className="relative">
            <input
              id="search-input"
              type="text"
              className="w-full px-6 py-3 text-base bg-white rounded-xl shadow-sm border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent font-sans"
              placeholder={translations[lang].search.placeholder}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              onFocus={() => setIsSearchFocused(true)}
              onBlur={() => setTimeout(() => setIsSearchFocused(false), 200)}
            />
            {isCalculation && (
              <div className="absolute right-24 top-1/2 transform -translate-y-1/2 text-blue-500 font-medium">
                {isCalculation}
              </div>
            )}
            <div className="absolute right-4 top-1/2 transform -translate-y-1/2 flex items-center gap-2 text-gray-400">
              <kbd className="px-2 py-1 text-xs bg-gray-100 rounded-md">⌘K</kbd>
              <Search className="w-5 h-5" />
            </div>
          </div>
          {isSearchFocused && (
            <SearchResults 
              results={filteredBrands}
              searchTerm={searchTerm}
              onClose={() => setIsSearchFocused(false)}
              onBrandClick={handleBrandClick}
            />
          )}
          <div className="mt-4">
            {recentSearches.length > 0 && (
              <div className="flex flex-wrap gap-2 justify-center">
                {recentSearches.map((brand) => (
                  <a
                    key={brand.id}
                    href={brand.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs px-3 py-1 bg-gray-50 hover:bg-gray-100 rounded-full text-gray-600 flex items-center gap-1 transition-colors"
                  >
                    <span className="w-1.5 h-1.5 bg-blue-400 rounded-full"></span>
                    {brand.name}
                  </a>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

//export default Dashboard;
