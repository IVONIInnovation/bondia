// src/components/brands.ts
export type Brand = {
  id: string;
  name: string;
  url: string;
  description: string;
  subbrands?: Brand[];
  parentId?: string;
};

export const brands: Brand[] = [
  {
    id: 'ivoni-core',
    name: 'IVONI Core',
    url: 'https://core.ivoni.org',
    description: 'Core brand services and solutions',
    subbrands: [
      {
        id: 'ivoni-housecore',
        name: 'IVONI Housecore',
        url: 'https://housecore.org',
        description: 'Comprehensive house style management'
      },
      {
        id: 'ivoni-brandcore',
        name: 'IVONI BrandCore',
        url: 'https://core.ivoni.org',
        description: 'Complete branding and identity solutions'
      }
    ]
  },
  {
    id: 'ivoni-global',
    name: 'IVONI',
    url: 'https://ivoni.org',
    description: 'Global digital transformation services',
    subbrands: [
      {
        id: 'ivoni-planblue',
        name: 'IVONI Plan Blue',
        url: 'https://ivoni.org/planblue',
        description: '100% Environmental Hosting'
      }
    ]
  },
  {
    id: 'ivoni-espana',
    name: 'IVONI España',
    url: 'https://ivoni.es',
    description: 'Spanish digital transformation services'
  },
  {
    id: 'ivoni-catalunya',
    name: 'IVONI Catalunya',
    url: 'https://ivoni.cat',
    description: 'Catalan digital transformation services'
  },
  {
    id: 'agencia-mira',
    name: 'AgenciaMira',
    url: 'https://agenciamira.es',
    description: 'Barcelona Based Creative Agency',
    subbrands: [
      {
        id: 'mirafest',
        name: 'MiraFest',
        url: 'https://mirafest.es',
        description: 'Barcelona Based Music Events'
      }
    ]
  }
];

export type Translation = {
  greeting: {
    morning: string;
    afternoon: string;
    evening: string;
  };
  search: {
    placeholder: string;
    save: string;
  };
};

export const translations: Record<string, Translation> = {
  EN: {
    greeting: {
      morning: 'Good Morning',
      afternoon: 'Good Afternoon',
      evening: 'Good Evening'
    },
    search: {
      placeholder: 'Search IVONI brands or find resources...',
      save: 'Save'
    }
  },
  ES: {
    greeting: {
      morning: 'Buenos Días',
      afternoon: 'Buenas Tardes',
      evening: 'Buenas Noches'
    },
    search: {
      placeholder: 'Buscar marcas, calcular o encontrar recursos...',
      save: 'Guardar'
    }
  },
  CAT: {
    greeting: {
      morning: 'Bon Dia',
      afternoon: 'Bona Tarda',
      evening: 'Bona Nit'
    },
    search: {
      placeholder: 'Cerca marques, calcula o troba recursos...',
      save: 'Desar'
    }
  }
};
