// src/components/Dashboard/LanguageSelector.tsx
import React, { useState, useEffect } from 'react';
import { Globe, ChevronDown } from 'lucide-react';

interface LanguageSelectorProps {
  selectedLang: string;
  onSelect: (lang: string) => void;
}

const LanguageSelector: React.FC<LanguageSelectorProps> = ({ selectedLang, onSelect }) => {
  const [isOpen, setIsOpen] = useState(false);
  
  const languages = [
    { code: 'EN', key: '1' },
    { code: 'ES', key: '2' },
    { code: 'CAT', key: '3' }
  ];

  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.metaKey || e.ctrlKey) {
        const key = e.key;
        const language = languages.find(lang => lang.key === key);
        if (language) {
          e.preventDefault();
          onSelect(language.code);
        }
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [onSelect, languages]);

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-3 py-2 text-sm bg-white rounded-lg border border-gray-200 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
      >
        <Globe className="w-4 h-4 text-gray-500" />
        <span>{selectedLang}</span>
        <ChevronDown className="w-4 h-4 text-gray-500" />
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 bg-white rounded-lg shadow-lg border border-gray-200 overflow-hidden z-50">
          {languages.map(({ code, key }) => (
            <button
              key={code}
              onClick={() => {
                onSelect(code);
                setIsOpen(false);
              }}
              className="w-full px-4 py-2 text-left text-sm hover:bg-gray-50 flex items-center justify-between"
            >
              <span>{code}</span>
              <kbd className="px-2 py-0.5 text-xs bg-gray-100 rounded">⌘{key}</kbd>
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

export default LanguageSelector;
