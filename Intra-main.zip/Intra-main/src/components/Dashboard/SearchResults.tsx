// src/components/Dashboard/SearchResults.tsx
import React from 'react';
import { ExternalLink } from 'lucide-react';
import { Brand } from '../data/brands';

interface SearchResultsProps {
  results: Brand[];
  searchTerm: string;
  onClose: () => void;
  onBrandClick: (brand: Brand) => void;
}

const DisplayUrl = ({ url }: { url: string }) => {
  if (!url) return null;
  try {
    const hostname = new URL(url).hostname.replace('www.', '');
    return (
      <div className="text-xs bg-gray-100 px-2 py-1 rounded text-gray-600">
        {hostname}
      </div>
    );
  } catch {
    return null;
  }
};

const SearchResults: React.FC<SearchResultsProps> = ({ 
  results, 
  searchTerm, 
  onClose, 
  onBrandClick 
}) => {
  if (!searchTerm) return null;

  return (
    <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-xl shadow-lg border border-gray-200 max-h-96 overflow-y-auto z-50">
      <div className="p-2">
        <div className="text-sm font-medium text-gray-500 px-3 py-2">
          {results.length ? `Found ${results.length} results` : 'No results found'}
        </div>
        {results.map(result => (
          
            key={result.id}
            href={result.url}
            target="_blank"
            rel="noopener noreferrer"
            className="block p-3 hover:bg-gray-50 rounded-lg group"
            onClick={(e) => {
              e.preventDefault();
              onBrandClick(result);
              window.open(result.url, '_blank', 'noopener,noreferrer');
            }}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4 flex-grow">
                <img
                  src={`/api/placeholder/32/32`}
                  alt={`${result.name} logo`}
                  className="w-8 h-8 rounded"
                />
                <div className="min-w-0 flex-grow">
                  <div className="font-medium text-gray-900 flex items-center gap-2">
                    {result.parentId && <span className="text-gray-400">↳</span>}
                    {result.name}
                  </div>
                  <div className="text-sm text-gray-500 truncate">{result.description}</div>
                </div>
                <div className="flex items-center gap-3 flex-shrink-0">
                  <DisplayUrl url={result.url} />
                  <div className="w-px h-4 bg-gray-200"></div>
                  <ExternalLink className="w-4 h-4 text-blue-500 opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
              </div>
            </div>
          </a>
        ))}
      </div>
    </div>
  );
};

export default SearchResults;
