// src/components/Dashboard/index.tsx
"use client";
"use client";

import React, { useState, useEffect } from 'react';
import { Search, Sun, Cloud, Calendar } from 'lucide-react';
import { brands, translations } from '../data/brands';
import SearchResults from './SearchResults';
import LanguageSelector from './LanguageSelector';
import type { Brand } from '../data/brands';

const Dashboard: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [time, setTime] = useState(new Date());
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const [lang, setLang] = useState('EN');
  const [recentSearches, setRecentSearches] = useState<Brand[]>([]);
  
// Helper function to flatten brands
const flattenBrands = (brandsArray: Brand[]) => {
  if (!Array.isArray(brandsArray) || brandsArray.length === 0) {
    return [];
  }

  return brandsArray.reduce<Brand[]>((acc, brand) => {
    // Add main brand
    acc.push({
      id: brand.id,
      name: brand.name,
      url: brand.url,
      description: brand.description,
      parentId: null
    });

    // Add subbrands if they exist
    if (Array.isArray(brand.subbrands)) {
      brand.subbrands.forEach(subbrand => {
        acc.push({
          id: subbrand.id,
          name: subbrand.name,
          url: subbrand.url || `https://${subbrand.id}.ivoni.org`,
          description: subbrand.description,
          parentId: brand.id
        });
      });
    }

    return acc;
  }, []);
};

export default function Dashboard() {
  const [searchTerm, setSearchTerm] = useState('');
  const [time, setTime] = useState(new Date());
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const [lang, setLang] = useState('EN');
  const [recentSearches, setRecentSearches] = useState<Brand[]>([]);
  
  const flatBrands = React.useMemo(() => flattenBrands(brands), []);
  
  const handleBrandClick = React.useCallback((brand: Brand) => {
    setRecentSearches(prevSearches => {
      const filteredSearches = prevSearches.filter(s => s.id !== brand.id);
      return [brand, ...filteredSearches].slice(0, 4);
    });
  }, []);

  const evaluateExpression = (expr: string) => {
    try {
      const sanitizedExpr = expr.replace(/×/g, '*').replace(/÷/g, '/');
      if (!/^[0-9+\-*/().\s×÷]+$/.test(sanitizedExpr)) {
        return null;
      }
      // eslint-disable-next-line no-new-func
      return Function(`'use strict'; return (${sanitizedExpr})`)();
    } catch {
      return null;
    }
  };

  const isCalculation = React.useMemo(() => {
    if (!searchTerm) return null;
    const result = evaluateExpression(searchTerm);
    return result !== null ? `= ${result}` : null;
  }, [searchTerm]);
  
  const filteredBrands = React.useMemo(() => {
    if (!searchTerm) return [];
    if (isCalculation) return [];
    const searchLower = searchTerm.toLowerCase();
    return flatBrands.filter(brand => 
      brand.name.toLowerCase().includes(searchLower) ||
      brand.description.toLowerCase().includes(searchLower)
    );
  }, [searchTerm, flatBrands, isCalculation]);

  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.key === 'k' && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        document.getElementById('search-input')?.focus();
      } else if (e.key === 'Escape') {
        setSearchTerm('');
        document.getElementById('search-input')?.blur();
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const getGreeting = () => {
    const hours = time.getHours();
    if (hours >= 5 && hours < 12) {
      return translations[lang].greeting.morning;
    } else if (hours >= 12 && hours < 18) {
      return translations[lang].greeting.afternoon;
    }
    return translations[lang].greeting.evening;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-8 py-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <img
                src="https://ivoni.org/wp-content/uploads/2021/11/IvoniLogo-Main-min.png"
                alt="IVONI IntraSystems Logo"
                className="w-12"
              />
              <div className="w-px h-6 bg-gray-200" />
              <span className="font-sans text-gray-800 font-medium">
                Intra-Sistema
              </span>
            </div>
            <LanguageSelector selectedLang={lang} onSelect={setLang} />
          </div>
        </div>
      </div>

      <div className="p-8 flex flex-col items-center justify-center min-h-[calc(100vh-64px)]">
        <div className="w-full max-w-3xl">
          <div className="flex flex-col items-center mb-8">
            <img
              src="https://core.ivoni.org/wp-content/uploads/2024/10/IVONI-IntraSistema.png"
              alt="IVONI IntraSystems Logo"
              className="w-32 mb-4"
            />
            <h1 className="text-4xl font-serif text-gray-800 text-center">
              {getGreeting()}
            </h1>
          </div>
          
          <div className="bg-white rounded-xl p-4 shadow-sm mb-8 w-full">
            <div className="flex flex-col sm:flex-row items-center justify-between text-sm text-gray-600 gap-4">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                {time.toLocaleDateString(lang === 'EN' ? 'en-GB' : 'es-ES', { 
                  weekday: 'long',
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric'
                })}
              </div>
              <div className="flex items-center gap-4 text-xs sm:text-sm">
                <div className="flex items-center gap-1">
                  <Sun className="w-3 h-3 sm:w-4 sm:h-4" />
                  <span className="whitespace-nowrap">
                    BCN: {time.toLocaleTimeString(lang === 'EN' ? 'en-GB' : 'es-ES', { 
                      timeZone: 'Europe/Madrid',
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                  </span>
                </div>
                <div className="flex items-center gap-1">
                  <Cloud className="w-3 h-3 sm:w-4 sm:h-4" />
                  <span className="whitespace-nowrap">
                    UK: {time.toLocaleTimeString(lang === 'EN' ? 'en-GB' : 'es-ES', { 
                      timeZone: 'Europe/London',
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                  </span>
                </div>
              </div>
            </div>
          </div>

          <div className="relative w-full">
            <div className="relative">
              <input
                id="search-input"
                type="text"
                className="w-full px-6 py-3 text-base bg-white rounded-xl shadow-sm border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent font-sans"
                placeholder={translations[lang].search.placeholder}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onFocus={() => setIsSearchFocused(true)}
                onBlur={() => setTimeout(() => setIsSearchFocused(false), 200)}
              />
              {isCalculation && (
                <div className="absolute right-24 top-1/2 transform -translate-y-1/2 text-blue-500 font-medium">
                  {isCalculation}
                </div>
              )}
              <div className="absolute right-4 top-1/2 transform -translate-y-1/2 flex items-center gap-2 text-gray-400">
                <kbd className="px-2 py-1 text-xs bg-gray-100 rounded-md">⌘K</kbd>
                <Search className="w-5 h-5" />
              </div>
            </div>
            
            {isSearchFocused && (
              <SearchResults 
                results={filteredBrands}
                searchTerm={searchTerm}
                onClose={() => setIsSearchFocused(false)}
                onBrandClick={handleBrandClick}
              />
            )}
            
            <div className="mt-4">
              {recentSearches.length > 0 && (
                <div className="flex flex-wrap gap-2 justify-center">
                  {recentSearches.map((brand) => (
                    
                      key={brand.id}
                      href={brand.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs px-3 py-1 bg-gray-50 hover:bg-gray-100 rounded-full text-gray-600 flex items-center gap-1 transition-colors"
                    >
                      <span className="w-1.5 h-1.5 bg-blue-400 rounded-full" />
                      {brand.name}
                    </a>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
